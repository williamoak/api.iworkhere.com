/**
 * @myDocBlock v2.3
 * @file DELETE.ts
 * @external
 * @module routes/v1/auth/token
 * @tag auth, logout, revoke
 * @version 1.0.0
 * @author william.r.oak@gmail.com
 * @path /v1/auth/token
 * @summary Revoke an authentication token.
 * @description
 * Explicitly revokes an access or refresh token. Used for logout,
 * security events, or credential changes. Revocation is immediate.
 *
 * @requestExample
 * {
 *   "token": "opaque-token"
 * }
 *
 * @response
 * (204 No Content)
 *
 * @requires
 * {
 *   "services": [
 *     "tokenService"
 *   ]
 * }
 */

import type { IncomingMessage, ServerResponse } from 'http'

import { revokeToken } from '@services/auth/tokenService'
import { AuthError } from '@services/auth/authContext'

/**
 * DELETE /v1/auth/token
 */
export default async function DELETE(
    req: IncomingMessage,
    res: ServerResponse
): Promise<void> {
    try {
        const body = (req as any).body
        const token = body?.token

        await revokeToken(token)

        res.statusCode = 204
        res.end()
    } catch (err) {
        if (err instanceof AuthError) {
            res.statusCode = err.httpStatus
            res.setHeader('Content-Type', 'application/json')
            res.end(
                JSON.stringify({
                    error: err.code,
                    message: err.message,
                })
            )
            return
        }

        res.statusCode = 500
        res.setHeader('Content-Type', 'application/json')
        res.end(
            JSON.stringify({
                error: 'INTERNAL_ERROR',
                message: 'An unexpected error occurred',
            })
        )
    }
}
