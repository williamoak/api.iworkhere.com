/**
 * @myDocBlock v2.3
 * @file emailVerificationService.ts
 * @internal
 * @module services/auth/emailVerificationService
 * @tag auth, email, verification
 * @version 1.0.0
 * @path none
 * @summary Verifies email ownership using a verification token.
 * @description
 * Validates an email verification token, activates the associated user,
 * records the verification timestamp, and invalidates the token.
 */

import { eq } from 'drizzle-orm'
import { db } from '@services/dbService'
import { AuthError } from '@services/auth/authContext'
import {
    users,
    emailVerificationTokens,
} from '@db/schema'

export async function verifyEmailToken(token: string): Promise<{
    id: string
    email: string
}> {
    if (!token || token.trim() === '') {
        throw new AuthError(
            'INVALID_TOKEN',
            'Verification token is required',
            400
        )
    }

    const rows = await db
        .select({
            userId: users.id,
            email: users.email,
            tokenId: emailVerificationTokens.id,
            expiresAt: emailVerificationTokens.expiresAt,
        })
        .from(emailVerificationTokens)
        .innerJoin(users, eq(users.id, emailVerificationTokens.userId))
        .where(
            eq(emailVerificationTokens.tokenHash, token)
        )
        .limit(1)

    if (rows.length === 0) {
        throw new AuthError(
            'TOKEN_INVALID',
            'Verification token is invalid',
            401
        )
    }

    const row = rows[0]

    if (row.expiresAt && row.expiresAt < new Date()) {
        throw new AuthError(
            'TOKEN_EXPIRED',
            'Verification token has expired',
            401
        )
    }

    await db.transaction(async (tx) => {
        await tx
            .update(users)
            .set({
                statusCode: 'active',
                emailVerifiedAt: new Date(),
            })
            .where(eq(users.id, row.userId))

        await tx
            .delete(emailVerificationTokens)
            .where(eq(emailVerificationTokens.id, row.tokenId))
    })

    return {
        id: row.userId,
        email: row.email!,
    }
}
