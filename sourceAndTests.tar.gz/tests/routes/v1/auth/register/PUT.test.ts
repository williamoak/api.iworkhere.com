/**
 * @myDocBlock v2.3
 * @file PUT.test.ts
 * @internal
 * @module tests/routes/v1/auth/register
 * @tag auth, register, test
 * @version 1.0.0
 * @path tests/routes/v1/auth/register/PUT.test.ts
 * @summary Tests PUT /v1/auth/register endpoint glue logic.
 */

import { describe, test, expect, vi, beforeEach } from 'vitest'
import type { IncomingMessage, ServerResponse } from 'http'

vi.mock('@services/auth/authContext', () => ({
    resolveAuthContext: vi.fn(),
    AuthError: class AuthError extends Error {
        constructor(
            public code: string,
            public message: string,
            public httpStatus: number
        ) {
            super(message)
        }
    },
}))

vi.mock('@services/auth/passwordService', () => ({
    hashPassword: vi.fn(),
    enforcePasswordHistory: vi.fn(),
}))

vi.mock('@services/dbService', () => ({
    db: {
        transaction: vi.fn(),
    },
}))

vi.mock('@db/schema', () => ({
    users: { id: 'id' },
    userAuthLocal: {},
    userApplications: {},
}))

import PUT from '@routes/v1/auth/register/PUT'
import { resolveAuthContext } from '@services/auth/authContext'
import { hashPassword } from '@services/auth/passwordService'
import { db } from '@services/dbService'

function createReq(body: any): IncomingMessage {
    return ({ body } as unknown) as IncomingMessage
}

function createRes(): ServerResponse & { body?: any } {
    return {
        statusCode: 0,
        setHeader() {},
        end(payload?: string) {
            if (payload) this.body = JSON.parse(payload)
        },
    } as any
}

beforeEach(() => {
    vi.resetAllMocks()
})

describe('PUT /v1/auth/register', () => {
    test('creates a user and returns 201', async () => {
        ;(resolveAuthContext as any).mockResolvedValue({ applicationId: 'app-id' })
        ;(hashPassword as any).mockResolvedValue('hashed')
        ;(db.transaction as any).mockImplementation(async (fn: any) =>
            fn({
                insert: () => ({
                    values: () => ({
                        returning: () => [{ id: 'user-id' }],
                    }),
                }),
            })
        )

        const req = createReq({
            app_key: 'bill.iworkhere.com',
            username: 'bill',
            email: 'bill@example.com',
            password: 'secret',
        })
        const res = createRes()

        await PUT(req, res)

        expect(res.statusCode).toBe(201)
        expect(res.body.user.username).toBe('bill')
    })

    test('returns 400 for missing fields', async () => {
        const req = createReq({ app_key: 'bill.iworkhere.com' })
        const res = createRes()

        await PUT(req, res)

        expect(res.statusCode).toBe(400)
    })
})
