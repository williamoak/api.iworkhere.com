/**
 * @myDocBlock v2.3
 * @file emailVerificationService.test.ts
 * @internal
 * @module tests/services/auth/emailVerificationService
 * @tag auth, email, verification, test
 * @version 1.0.0
 * @path tests/services/auth/emailVerificationService.test.ts
 * @summary Tests email verification service logic.
 * @description
 * Verifies correct handling of email verification tokens, including
 * invalid, expired, and valid tokens. Ensures user activation and
 * token invalidation occur atomically.
 */

import { describe, test, expect, vi, beforeEach } from 'vitest'

/**
 * ------------------------------------------------------------
 * MOCKS — MUST APPEAR BEFORE IMPORTS
 * ------------------------------------------------------------
 */

vi.mock('@services/dbService', () => ({
    db: {
        select: vi.fn(),
        transaction: vi.fn(),
    },
}))

vi.mock('@db/schema', () => ({
    users: {
        id: 'id',
        email: 'email',
        statusCode: 'status_code',
        emailVerifiedAt: 'email_verified_at',
    },
    emailVerificationTokens: {
        id: 'id',
        userId: 'user_id',
        tokenHash: 'token_hash',
        expiresAt: 'expires_at',
    },
}))

/**
 * ------------------------------------------------------------
 * IMPORTS (AFTER MOCKS)
 * ------------------------------------------------------------
 */

import { db } from '@services/dbService'
import { verifyEmailToken } from '@services/auth/emailVerificationService'

/**
 * ------------------------------------------------------------
 * HELPERS
 * ------------------------------------------------------------
 */

function mockSelectOnce(rows: any[]) {
    ;(db.select as any).mockReturnValueOnce({
        from: () => ({
            innerJoin: () => ({
                where: () => ({
                    limit: () => Promise.resolve(rows),
                }),
            }),
        }),
    })
}

beforeEach(() => {
    vi.resetAllMocks()
})

/**
 * ------------------------------------------------------------
 * TESTS
 * ------------------------------------------------------------
 */

describe('emailVerificationService.verifyEmailToken', () => {
    test('throws if token is missing', async () => {
        await expect(
            verifyEmailToken(undefined as any)
        ).rejects.toMatchObject({
            code: 'INVALID_TOKEN',
            httpStatus: 400,
        })
    })

    test('throws if token is not found', async () => {
        mockSelectOnce([])

        await expect(
            verifyEmailToken('missing-token')
        ).rejects.toMatchObject({
            code: 'TOKEN_INVALID',
            httpStatus: 401,
        })
    })

    test('throws if token is expired', async () => {
        mockSelectOnce([
            {
                userId: 'user-id',
                email: 'user@example.com',
                tokenId: 'token-id',
                expiresAt: new Date(Date.now() - 1000),
            },
        ])

        await expect(
            verifyEmailToken('expired-token')
        ).rejects.toMatchObject({
            code: 'TOKEN_EXPIRED',
            httpStatus: 401,
        })
    })

    test('activates user and deletes token on success', async () => {
        mockSelectOnce([
            {
                userId: 'user-id',
                email: 'user@example.com',
                tokenId: 'token-id',
                expiresAt: new Date(Date.now() + 100000),
            },
        ])

        ;(db.transaction as any).mockImplementation(
            async (fn: any) => {
                await fn({
                    update: () => ({
                        set: () => ({
                            where: () => Promise.resolve(),
                        }),
                    }),
                    delete: () => ({
                        where: () => Promise.resolve(),
                    }),
                })
            }
        )

        const result = await verifyEmailToken('valid-token')

        expect(result).toEqual({
            id: 'user-id',
            email: 'user@example.com',
        })

        expect(db.transaction).toHaveBeenCalledOnce()
    })
})
