/**
 * @file tests/auth/eula/GET.test.ts
 * @summary Tests for GET /v1/auth/eula
 */

import { describe, it, expect, beforeAll, afterAll } from "vitest";
import request from "supertest";

import { db } from "@services/dbService";
import { configTable } from "@db/schema/config";
import { uuidv7 } from "uuidv7";

// ⚠️ adjust this import to your actual app export
import app from "@app";

/**
 * Helper: insert EULA config row
 */
async function insertEula(version: string, value: any) {
    await db.insert(configTable).values({
        id: uuidv7(),
        name: "eula",
        version,
        value,
    });
}

describe("GET /v1/auth/eula", () => {

    beforeAll(async () => {
        // Clean slate for EULA records
        await db
            .delete(configTable)
            .where(configTable.name.eq("eula"));

        // Seed two versions
        await insertEula("1.00", {
            title: "EULA v1",
            text: "Original terms",
        });

        await insertEula("2.10", {
            title: "EULA v2.10",
            text: "Updated terms",
        });
    });

    afterAll(async () => {
        // Cleanup
        await db
            .delete(configTable)
            .where(configTable.name.eq("eula"));
    });

    it("returns the latest EULA when no version is specified", async () => {
        const res = await request(app)
            .get("/v1/auth/eula")
            .expect(200);

        expect(res.body).toMatchObject({
            name: "eula",
            version: "2.10",
            value: {
                title: "EULA v2.10",
            },
        });
    });

    it("returns a specific EULA version when version is specified", async () => {
        const res = await request(app)
            .get("/v1/auth/eula")
            .query({ version: "1.00" })
            .expect(200);

        expect(res.body).toMatchObject({
            name: "eula",
            version: "1.00",
            value: {
                title: "EULA v1",
            },
        });
    });

    it("returns 404 when the requested EULA version does not exist", async () => {
        await request(app)
            .get("/v1/auth/eula")
            .query({ version: "9.99" })
            .expect(404);
    });

});
